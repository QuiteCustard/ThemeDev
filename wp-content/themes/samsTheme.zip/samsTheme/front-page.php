<?php
get_header();

while( have_posts() ): ?>
    <?php the_post(); ?>
    <div class="actual-content">
    <a class="" href="<?php the_permalink(); ?>">
    <?php echo get_option( 'samsTheme_readmore_text', __( 'Read More', 'samsTheme' ) ); ?>
	</a>
        <?php the_content(); ?>
    </div>
<?php endwhile; ?>
 
 <?php get_footer(); ?>





 <?php
 /*

 Read more for exerpt box
 <a class="read-more-link" href="<?php the_permalink(); ?>">
    <?php echo get_option( 'nd_dosth_readmore_text', __( 'Read More', 'nd_dosth' ) ); ?>
</a> */?>