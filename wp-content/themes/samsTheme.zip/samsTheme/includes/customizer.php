<?php

add_action('customize_register', 'samsTheme_customize_register');

function samsTheme_customize_register($wp_customize){
    // Theme Colour Panel
    $wp_customize->add_panel( 'samsTheme_colour', 
        array(
            'title'            => __( 'Colours', 'samsTheme' ),
            'description'      => __( 'Theme Modifications like theme colours', 'samsTheme' ),
        ) 
    );

    // Colour Options Section Inside Theme
    $wp_customize->add_section( 'samsTheme_colour_options', 
        array(
            'title'         => __( 'Main', 'samsTheme' ),
            'priority'      => 1,
            'panel'         => 'samsTheme_colour',
        ) 
    );

    // Add a new setting for primary colour.
    $wp_customize->add_setting( 'samsTheme_colour_primary',
        array(
            'default'              => 'fdb813',
            'sanitize_callback'    => 'sanitize_hex_color_no_hash',
            'sanitize_js_callback' => 'maybe_hash_hex_color',
            'transport'            => 'postMessage',
        )
    );

    // Add a control for primary colour.
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'samsTheme_colour_primary',
            array(
                'label'         => esc_html__( 'Primary Colour', 'samsTheme' ),
                'section'       => 'samsTheme_colour_options',
                'settings'      => 'samsTheme_colour_primary',
            )
        )
    );

    // Add a new setting for Secondary colour.
    $wp_customize->add_setting( 'samsTheme_colour_secondary',
        array(
            'default'              => '1a3794',
            'type'                 => 'option',
            'sanitize_callback'    => 'sanitize_hex_color_no_hash',
            'sanitize_js_callback' => 'maybe_hash_hex_color',
            'transport'            => 'postMessage',
        )
    );
    // Add a control for Secondary colour.
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'samsTheme_colour_secondary',
            array(
                'label'         => esc_html__( 'Secondary Colour', 'samsTheme' ),
                'section'       => 'samsTheme_colour_options',
                'settings'      => 'samsTheme_colour_secondary',
            )
        )
    );

    // Add a new setting for link colours.
    $wp_customize->add_setting( 'samsTheme_colour_link',
        array(
            'default'              => '61f213',
            'type'                 => 'option',
            'sanitize_callback'    => 'sanitize_hex_color_no_hash',
            'sanitize_js_callback' => 'maybe_hash_hex_color',
            'transport'            => 'postMessage',
        )
    );
    // Add a control for Link colour.
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'samsTheme_colour_link',
            array(
                'label'         => esc_html__( 'Link Colour', 'samsTheme' ),
                'section'       => 'samsTheme_colour_options',
                'settings'      => 'samsTheme_colour_link',
            )
        )
    );
    // Theme Options Panel
    $wp_customize->add_panel( 'samsTheme_options', 
        array(
            'title'            => __( 'Theme Options', 'samsTheme' ),
            'description'      => __( 'Theme Modifications like theme texts', 'samsTheme' ),
        ) 
    );

    // Text Options Section Inside Theme
    $wp_customize->add_section( 'samsTheme_text_options', 
        array(
            'title'         => __( 'Text Options', 'samsTheme' ),
            'priority'      => 1,
            'panel'         => 'samsTheme_options',
        ) 
    );

    // Setting for Read More text.
    $wp_customize->add_setting( 'samsTheme_readmore_text',
        array(
            'type'              => 'option',
            'default'           => __( 'Read More ', 'samsTheme' ),
            'sanitize_callback' => 'sanitize_text_field',
            'transport'         => 'refresh',
        )
    );

    // Control for Read More text
    $wp_customize->add_control( 'samsTheme_readmore_text', 
        array(
            'type'        => 'text',
            'priority'    => 10,
            'section'     => 'samsTheme_text_options',
            'label'       => 'Read More text',
            'description' => 'Text put here will be as the text for Read More link on the homepage',
            'active_callback' => 'is_front_page',
        ) 
    );
}

// Registers the Theme Customizer Preview with WordPress.
function samsTheme_customize_live_preview() {
    wp_enqueue_script(
        'samsTheme-customize-js',
        get_stylesheet_directory_uri() . '/js/customizer.js',
        array( 'jquery', 'customize-preview' ),
        '',
        true
    );
}
add_action( 'customize_preview_init', 'samsTheme_customize_live_preview' );


// Generate Internal CSS from the values Customize Panel Settings
 
function samsTheme_customization_css(){
    $style = '';
    //Get Options from the Customize Panel
    $primary_colour_code     = get_option( 'samsTheme_colour_primary', 'fdb100' );
    $secondary_colour_code   = get_option( 'samsTheme_colour_secondary', '1a3794' );
    $link_colour_code     = get_option( 'samsTheme_colour_link', 'fdb100' );
?>
<style>
    :root{
        --link:#<?php echo $link_colour_code; ?>;
    }
</style>
<?php
}
add_action( 'wp_head', 'samsTheme_customization_css' );

