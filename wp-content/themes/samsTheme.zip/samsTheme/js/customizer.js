(function ($) {

    // Shows a live preview of changing the link colour of the theme.
    wp.customize('samsTheme_colour_link', function (color_code) {
        color_code.bind(function (updated_color_code) {
            $('a').css('color', updated_color_code);
        });
    });
})(jQuery);